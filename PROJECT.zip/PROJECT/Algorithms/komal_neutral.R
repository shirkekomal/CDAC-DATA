
install.packages("neuralnet")
library(neuralnet)

is.na(yourtable)<-"0"
yourtable
h<-head(yourtable)
h
h<-yourtable[1:300,]
# Training Network
s1 <- neuralnet(imdb_score~actor_1_facebook_likes+actor_2_facebook_likes+actor_3_facebook_likes+director_facebook_likes+cast_total_facebook_likes+movie_facebook_likes+num_user_for_reviews,
                h,
                hidden = 12, threshold = 0.1)


# Plot Neural Network
plot(s1,rep="best")
s1
temp_test <- subset(h, select = c("actor_1_facebook_likes","actor_2_facebook_likes","actor_3_facebook_likes","director_facebook_likes", "cast_total_facebook_likes","movie_facebook_likes","num_user_for_reviews"))

s1.results <- compute(s1, temp_test)
names(s1.results)
p <- round(s1.results$net.result,digit = 0)
results <- data.frame(name_movie=h$movie_title,actual = h$imdb_score, prediction = s1.results$net.result)
results[101:200,]
head(results,21:30)

#MSE : mean square error
mean((h$imdb_score-s1.results$net.result)^2)


