#Regression trees
install.packages("randomForest")

library(rpart)
temp <- na.omit(yourtable[,columns]) 
set.seed(2)
train <- sample(dim(temp)[1],dim(temp)[1]*0.9)
head(train)
temp_train <- temp[train,]
temp_test <- temp[-train,]


set.seed(3)
m.rpart <- rpart(imdb_score~.,data=temp_train)
m.rpart

#Visualizing the tree
rpart.plot(m.rpart,digits = 3)

#Testing above model
p.rpart <- predict(m.rpart,temp_test)
  #-saving to df
tree_dataframe <- data.frame(p.rpart,temp_test$imdb_score)
  #-ggplot hist for df of p.rpart i.e predicted
ggplot(tree_dataframe, aes(x=p.rpart)) + geom_histogram(fill="white", colour="black")
  #-ggplot hist for df of p.rpart i.e actual
ggplot(tree_dataframe, aes(x=temp_test.imdb_score)) + geom_histogram(fill="white", colour="black")

#correlation between the predicted and the actual values
cor(p.rpart,temp_test$imdb_score)

#MSE
mean((p.rpart-temp_test$imdb_score)^2)

#Random Forests regression 
set.seed(1)
library(randomForest)

head(temp[train,])
dim(temp)[2]/3
rf <- randomForest(imdb_score~.,data=temp[train,],ntree=50,importance=TRUE,ntree=floor(dim(temp)[2]/3))
pred_rf <- predict(rf,temp[-train,])
mean((pred_rf-temp[-train,]$imdb_score)^2)
