
install.packages("neuralnet")
install.packages("nnet")
library(neuralnet)
library(nnet)
is.na(yourtable)<-"0"
yourtable

h<-tail(yourtable)
# Training Network
s1 <- neuralnet(imdb_score~actor_1_facebook_likes+actor_2_facebook_likes+actor_3_facebook_likes+director_facebook_likes+cast_total_facebook_likes+movie_facebook_likes+num_user_for_reviews,
                h,
                hidden = 4, threshold = 00.1)


# Plot Neural Network
plot(s1,rep="best")
s1
temp_test <- subset(h, select = c("actor_1_facebook_likes","actor_2_facebook_likes","actor_3_facebook_likes","director_facebook_likes", "cast_total_facebook_likes","movie_facebook_likes","num_user_for_reviews"))

s1.results <- compute(s1, temp_test)
names(s1.results)
results <- data.frame(name_movie=h$movie_title,actual = h$imdb_score, prediction = s1.results$net.result)

tail(results)



