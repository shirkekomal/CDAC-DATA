install.packages("tm")
install.packages("wordcloud")
install.packages("slam")
install.packages("ggplot2")
install.packages("topicmodels")
library(tm)

library(wordcloud)
library(slam)
library(topicmodels)

#Load Text
con <- read.csv("C:\\Users\\160840320033\\Downloads\\Training.csv", header = TRUE, sep = ",")

data <- con$plot_keywords
#Clean Text
data = gsub("(RT|via)((?:\\b\\W*@\\w+)+)","",data)
data = gsub("http[^[:blank:]]+", "", data)
data = gsub("@\\w+", "", data)
data = gsub("[ t]{2,}", "", data)
data = gsub("^\\s+|\\s+$", "", data)
data <- gsub('\\d+', "", data)
data = gsub("[[:punct:]]", "", data)
corpus = Corpus(VectorSource(data))
corpus = tm_map(corpus,removePunctuation)
corpus = tm_map(corpus,stripWhitespace)
corpus = tm_map(corpus,tolower)
#corpus = tm_map(corpus,removeWords,stopwords("english"))

tdm = TermDocumentMatrix(corpus, control = list(wordLengths = c(1, Inf))) # Creating a Term document Matrix
tdm2
## Freqency words and Association
idx <- which(dimnames(tdm)$Terms == "r")
inspect(tdm[idx + (0:5), 101:110])

#inspect frequent words
(freq.terms <- findFreqTerms(tdm, lowfreq=15))

term.freq <- rowSums(as.matrix(tdm))
term.freq <- subset(term.freq, term.freq >=5)
df <- data.frame(term = names(term.freq), freq = term.freq)

library(ggplot2)

ggplot(df, aes(x=term, y=freq)) + geom_bar(stat = "identity") + xlab("Terms") + ylab("Count") +coord_flip()

# which words are associated with 'r'?
#findAssocs(tdm, "r", 0.2)
# which words are associated with 'mining'?
#findAssocs(tdm, "mining", 0.25)

install.packages("wordcloud")
library(wordcloud)

#plot(tdm, term = freq.terms, corThreshold = 0.12, weighting = T)

m <- as.matrix(tdm)
# calculate the frequency of words and sort it by frequency
word.freq <- sort(rowSums(m), decreasing = T)
wordcloud(words = names(word.freq), freq = word.freq, min.freq = 3,
          random.order = F)
head(word.freq)
dtm
raw.sum=apply(tdm,1,FUN=sum) #sum by raw each raw of the table
raw.sum
table1=tdm[raw.sum!=0,]
table1
dtm <- as.DocumentTermMatrix(tdm)
library(topicmodels)
lda <- LDA(table1, k = 5) # find 8 topics
term <- terms(lda, 5) # first 4 terms of every topic
term

term <- apply(term, MARGIN = 2, paste, collapse = ", ")

# first topic identified for every document (tweet)
require(data.table) #for IDate

topic <- topics(lda, 1)

head(term[topic])


topics <- data.frame(date=as.IDate(tweets.df$created), topic)
qplot(date, ..count.., data=topics, geom="density",
      fill=term[topic], position="stack")

library(tm)

# remove sparse terms
tdm2 <- removeSparseTerms(tdm, 0.95)
m2 <- as.matrix(tdm2)
m2
m3 <- t(m2) # transpose the matrix to cluster documents (tweets)
m3
set.seed(122) # set a fixed random seed
k <- 6 # number of clusters
kmeansResult <- kmeans(m3, k)
round(kmeansResult$centers, digits = 3) # cluster centers



# cluster terms
distMatrix <- dist(scale(m2))
fit <- hclust(distMatrix, method = "complete")

plot(fit)
rect.hclust(fit, k = 6) # cut tree into 6 clusters 
