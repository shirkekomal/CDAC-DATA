library(mice)
library(caTools)
library(xgboost)
library(corrplot)

setwd("C:/Users/AMOD/Documents/Q-Comp")
m = read.csv("Training.csv", stringsAsFactors = FALSE)

colnames = colnames(m)


m[m == ""] <- NA

Mode <- function(x) {
  ux <- na.omit(unique(x) )
  tab <- tabulate(match(x, ux)); ux[tab == max(tab) ]
}


Mode(m[,2])

m$director_name = ifelse(is.na(m$director_name) == TRUE, "Others", m$director_name)
m$actor_2_name = ifelse(is.na(m$actor_2_name) == TRUE, "Others", m$actor_2_name)
m$actor_1_name = ifelse(is.na(m$actor_1_name) == TRUE, "Others", m$actor_1_name)
m$actor_3_name = ifelse(is.na(m$actor_3_name) == TRUE, "Others", m$actor_3_name)

m1 = m[,17]

for(i in 1:ncol(m1)){
  for(j in 1:nrow(m1)){
    m1[j,i] = ifelse(is.na(m1[j,i]) == TRUE & class(m[,i]) == "character", Mode(m1[,i]), m[j,i])
    }
}

Mean <- function(x) {
  mean(x, na.rm = TRUE)
}

for(i in 1:ncol(m)){
  for(j in 1:nrow(m)){
    m[j,i] = ifelse(is.na(m[j,i]) == TRUE & class(m[,i]) == "integer", Mean(m[,i]), m[j,i])
  }
}

for(i in 1:ncol(m)){
  for(j in 1:nrow(m)){
    m[j,i] = ifelse(is.na(m[j,i]) == TRUE & class(m[,i]) == "numeric", Mean(m[,i]), m[j,i])
  }
}

m = as.data.frame(unclass(m))
#m1 = m1[,-26]
sample = sample.split(m$imdb_score, SplitRatio = 0.7)
train = subset(m, sample == TRUE)
test = subset(m, sample == FALSE)

train1 = train[,-26]
test1 = test[,-26]

train_mat <- matrix(as.numeric(data.matrix(train1)),ncol = 27)
test_mat <- matrix(as.numeric(data.matrix(test1)),ncol = 27)
#CV_mat <- matrix(as.numeric(data.matrix(CV)),ncol = 27)

params = list(verbose=1, 
              eta=0.2, 
              max_depth=6, 
              objective='reg:linear', 
              num_parallel_tree = 1,
              min_child_weight = 1,
              base_score = 7)

xgb_model_test = xgboost(data=train_mat, 
                          label= train$imdb_score, 
                          nrounds = 30,
                          params = params,
                          missing="NAN")


test_preds <- predict(xgb_model_test, test_mat, missing = "NAN")
test_preds_frame <- data.frame(matrix(test_preds, ncol = 1, byrow=TRUE))
colnames(test_preds_frame) <- c("target")

t = test_preds_frame
t$actualRatings = test$imdb_score
t$absdiff = abs(t$actualRatings - t$target)

sum(t$absdiff)


results = test_preds_frame
results$movie_imdb_link = test$movie_imdb_link
results$imdb_score = test_preds_frame$target
results = results[,-1]

write.csv(m, "trm.csv", row.names = FALSE)
