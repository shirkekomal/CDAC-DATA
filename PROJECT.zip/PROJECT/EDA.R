c = cor(m2)
corrplot(c, method = "circle")

library(formattable)
library(ggplot2)
library(plotly)
library(dplyr)

temp <- m %>% select(imdb_score,title_year)
temp <- temp %>% group_by(title_year)%>% summarise(score=mean(imdb_score))
temp <- na.omit(temp)

m <- m[order(-m$budget),]


ggplot(temp , aes(x = title_year , y = score)) + geom_line(group = 1) + geom_smooth()

ggplot(m , aes(x = director_facebook_likes , y = imdb_score)) + geom_line(group = 1) + geom_smooth()

ggplot(m[30:nrow(m),] , aes(x = budget , y = imdb_score)) + geom_line(group = 1) + geom_smooth()




temp <- m %>% select(director_name,imdb_score)
temp <- temp %>% group_by(director_name) %>% summarise(num= n()) %>% tally(n = sort)
temp <- temp %>% arrange(desc(avg))#%>% tally()
temp <- temp[1:20,]
temp %>%
  formattable(list(avg = color_bar("orange")), align = 'l')

lmodel = lm(imdb_score ~ num_critic_for_reviews, m)


