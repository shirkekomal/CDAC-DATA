import java.util.*;

class item
{
	Integer id;
	String name;
	
				item(Integer i,String name)
				{
					this.id=i;
					this.name=name;
				}
	
	@Override
	public boolean equals(Object o)
	{
		if(!(o instanceof item))
		{
			return false;
		}
		else
		{
			item temp=(item)o;
			if(this.id.equals(temp.id)&&

			   this.name.equals(temp.name))
			   {
				   return true;
			   }
			   else{
				   return false;
			   }
		}
	}
	@Override
	public int hashCode()
	{
		int result=0;
		int a=5;
		
		result=result*a+name.hashCode();
		result=result*a+id.hashCode();
		return result;
	}
	
	public String toString()
	{
			return "ID-->>"+this.id+"Name-->>"+this.name;
	}
	public static void main(String args[])
	{
		List<Student> l=new ArrayList<>();
		Scanner sc=new Scanner(System.in);
		
		do
		{
			System.out.println("Enter choice1:insert 2:sort 3:remove 4:exit");
		int ch=sc.nextInt();
		switch(ch)
		{
			case 1:
				System.out.println("Enter name");
				String name=sc.next();
				System.out.println("Enter Id");
				Integer id=sc.nextInt();
				
				item i=new item(name,id);
				l.add(i);
				break;
				
			case 2:
				System.out.println(l);
				break;
				
		}
		}while(ch!=4)
		
	}
}