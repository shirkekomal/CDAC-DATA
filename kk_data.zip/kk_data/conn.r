library(RMySQL)
con <- dbConnect(MySQL(), user="Unicorn", password="Unicorn", 
                 dbname="unicorn", host="localhost",client.flag=CLIENT_MULTI_STATEMENTS)

dbListTables(con)
yourtable <- dbReadTable(con,"unicorntable")
yourtable<-data2
# write it back
dbWriteTable(con,"unicorntable",yourtable,overwrite=T,encoding = "utf-8")
# watch out with the overwrite argument it does what it says :)
dbDisconnect(con)

yourtable
save(yourtable,file="data.Rda")
load("data.Rda")
print(yourtable)
yourtable
options(max.print=100000)
yourtable
dbWriteTable(con, value = yourtable, name = "unidata", append = TRUE,encoding = "utf-8")

colnames(yourtable)[colnames(yourtable)=="�..color"] <- "color"
names(yourtable) <- c("�..color","color")
yourtable
install.packages('data.table')
library(data.table)
names(yourtable)[1] <- "color"
view(yourtable)
data2
head(data2)
names(yourtable) <- c("color","director_name","num_critic_for_reviews","duration","director_facebook_likes","actor_3_facebook_likes","actor_2_name","actor_1_facebook_likes","gross","genres","actor_1_name","movie_title","num_voted_users","cast_total_facebook_likes","actor_3_name","facenumber_in_poster","plot_keywords","movie_imdb_link","num_user_for_reviews","language","country","content_rating","budget","title_year","actor_2_facebook_likes","imdb_score","aspect_ratio","movie_facebook_likes")
matrix<-cor(yourtable)
install.packages('corrplot')
