
hist(data2)
install.packages('RMySQL')
data2
view(data1)
data
1+2
read.csv()