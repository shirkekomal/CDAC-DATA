
library(corrplot)
m <-yourtable$director_facebook_likes
num_critic_for_reviews<-yourtable$num_critic_for_reviews
n <- cor(m,use ="complete.obs")
imdb_score<-yourtable$imdb_score

hist(imdb_score)
barplot(m,n)
barplot(dat$y, names.arg=dat$x, ylim=c(0,5), ylab="blah", xlab="lol")

install.packages('tm')
updateR()
t<-count(city,c("USA","UK","France"))

#piechart
install.packages('plyr')

library('plyr')

a <- count(yourtable$language)
names(a)[1] = 'language'
a$freq
class(a)


sorted_a<-arrange(a,desc(freq),language)
sorted_a

pie(head(sorted_a$freq),head(sorted_a$language),radius=0.9,col=rainbow(length(sorted_freq)))
