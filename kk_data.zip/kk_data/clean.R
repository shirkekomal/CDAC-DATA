yourtable<-read.csv(file = "C:\\Users\\160840320032\\Documents\\Training.csv",header = TRUE)
is.na(yourtable) <- "0"
yourtable
yourtable<- sapply(yourtable, as.character)
is.na(yourtable)<-"unknown"
head(yourtable)


write.csv(yourtable, file = "C:\\Users\\160840320032\\Documents\\Testing1.csv")
