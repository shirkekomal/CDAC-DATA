
#language
library('plyr')
library('ggplot2')

a <- count(yourtable$language)
names(a)[1] = 'language'
a
sorted_a<-arrange(a,desc(freq),language)
h_a <- head(sorted_a)
h_a
pie <- ggplot(h_a, aes(x = factor(freq), fill = factor(language))) +
  geom_bar(width = 1)+scale_fill_manual(values = c("red", "orange","violet","navyblue","brown","light green"))
pie + coord_polar(theta = "y")

#country
library('plyr')
library('ggplot2')

a <- count(yourtable$country)
names(a)[1] = 'country'
a
a$freq
sorted_a<-arrange(a,desc(freq),country)
h_a <- head(sorted_a)
h_a
pie <- ggplot(h_a, aes(x = factor(freq), fill = factor(country))) +
  geom_bar(width = 1)+scale_fill_manual(values = c("red", "orange","violet","light green","brown","navyblue"))
pie + coord_polar(theta = "y")

pie(h_a$freq,h_a$country,col=rainbow(length(h_a$freq)))

#aspect ratio
library('plyr')
library('ggplot2')

a <- count(yourtable$aspect_ratio)
names(a)[1] = 'aspect_ratio'
a
a$freq
sorted_a<-arrange(a,desc(freq),aspect_ratio)
h_a <- head(sorted_a)
h_a
pie <- ggplot(h_a, aes(x = factor(freq), fill = factor(aspect_ratio))) +
  geom_bar(width = 1)+scale_fill_manual(values = c("red", "orange","violet","light green","brown","navyblue"))
pie + coord_polar(theta = "y")

pie(h_a$freq,h_a$aspect_ratio,col=rainbow(length(h_a$freq)))

#title_year
library('plyr')
library('ggplot2')
yourtable$title_year
a <- count(yourtable$title_year)
names(a)[1] = 'title_year'
a
a$freq
sorted_a<-arrange(a,desc(freq),title_year)
h_a <- head(sorted_a)
h_a
pie <- ggplot(h_a, aes(x = factor(freq), fill = factor(title_year))) +
  geom_bar(width = 1)+scale_fill_manual(values = c("red", "orange","violet","light green","brown","navyblue"))
pie + coord_polar(theta = "y")

pie(h_a$freq,h_a$title_year,col=rainbow(length(h_a$freq)))

#color
library('plyr')
library('ggplot2')
yourtable$title_year
a <- count(yourtable$color)
names(a)[1] = 'color'
a

a$freq
sorted_a<-arrange(a,desc(freq),color)
h_a <- head(sorted_a)
h_a
pie <- ggplot(h_a, aes(x = factor(freq), fill = factor(color))) +
  geom_bar(width = 1)+scale_fill_manual(values = c("red", "orange","violet","light green","brown","navyblue"))
pie + coord_polar(theta = "y")

pie(h_a$freq,h_a$color,col=rainbow(length(h_a$freq)))


