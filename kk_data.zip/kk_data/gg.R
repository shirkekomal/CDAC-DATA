library('plyr')
library('ggplot2')
yourtable$title_year
a <- count(yourtable$imdb_score)
b <- count(yourtable$director_facebook_likes)
names(a)[1] = 'imdb_score'
names(b)[1] = 'director_facebook_likes'
a
b
c <- c(a,b)
a$freq
sorted_a<-arrange(a,desc(freq),imdb_score)
h_a <- head(sorted_a)
h_a
a_l <- as.numeric(a)
class(a_l)
xy.coords(a_l, b, "xlabel", "ylabel")
plot(a,b,type = "o",col="red",xlab="color",ylab="freq")
