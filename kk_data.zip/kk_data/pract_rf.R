install.packages("tm")
install.packages("proxy")
install.packages("ggplot2")
install.packages("topicmodels")
library(proxy)
library(tm)
library(slam)
library(topicmodels)

#Load Text\
con <- read.csv("C:\\Users\\160840320032\\Desktop\\PROJECT\\Training.csv", header = TRUE, sep = ",")

data <- con$genres
#Clean Text
data = gsub("(RT|via)((?:\\b\\W*@\\w+)+)","",data)
data = gsub("http[^[:blank:]]+", "", data)
data = gsub("@\\w+", "", data)
data = gsub("[ t]{2,}", "", data)
data = gsub("^\\s+|\\s+$", "", data)
data <- gsub('\\d+', "", data)
data = gsub("[[:punct:]]", "", data)

corpus = Corpus(VectorSource(data))
corpus = tm_map(corpus,removePunctuation)
corpus = tm_map(corpus,stripWhitespace)
corpus = tm_map(corpus,tolower)
#corpus = tm_map(corpus,removeWords,stopwords("english"))


tdm = TermDocumentMatrix(corpus, control = list(wordLengths = c(1, Inf))) # Creating a Term document Matrix
tdm
head(dimnames(tdm)$Terms)
## Freqency words and Association
idx <- which(dimnames(tdm)$Terms == "a")
idx
inspect(tdm[idx + (0:5), 101:110]) #<---- error......print (0,1)mtrix

#dissimilarity(tdm,method = "cosine")

#inspect frequent words
(freq.terms <- findFreqTerms(tdm, lowfreq=15))

term.freq <- rowSums(as.matrix(tdm))
term.freq <- subset(term.freq, term.freq >=5)
df <- data.frame(term = names(term.freq), freq = term.freq)
head(df)

library(ggplot2)

ggplot(head(df,20), aes(x=term, y=freq)) + geom_bar(stat = "identity") + xlab("Terms") + ylab("Count") +coord_flip()

raw.sum=apply(tdm,1,FUN=sum) #sum by raw each raw of the table
raw.sum
table1=tdm[raw.sum!=0,]
table1
dtm <- as.DocumentTermMatrix(tdm)

dtm

library(topicmodels)
lda <- LDA(table1, k = 5)# find 8 topics
lda
term <- terms(lda, 5) # first 4 terms of every topic
term

term <- apply(term, MARGIN = 2, paste, collapse = ", ")
term
