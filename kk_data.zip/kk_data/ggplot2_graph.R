install.packages("ggplot2")
library(ggplot2)
library(plyr)
a <- count(yourtable$language)
a
names(a)[1] = 'language'
a$freq
a
sorted_a<-arrange(a,desc(freq),language)
h_a <- head(sorted_a)
pie <- ggplot(h_a, aes(x = h_a$language, factor(1),fill=factor(h_a$freq),stat="bin",col = h_a$freq )) 
pie <- pie + geom_bar(width = .05)
pie <- pie+coord_polar(theta = "y")

plot(pie)


ggplot(h_a, aes(x = language, factor(1),fill=factor(freq),stat="bin",col = freq ))+coord_polar(theta = "y")+geom_smooth(aes(group=1,method=x))


install.packages(sqldf)
library(sqldf)



rnorm(20)

