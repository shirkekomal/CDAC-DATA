install.packages('e1071')
library(e1071)

movie_facebook_likes = yourtable$movie_facebook_likes
actor_1_facebook_likes=yourtable$actor_1_facebook_likes
imdb_score = factor(yourtable$imdb_score)

d = data.frame(movie_facebook_likes=movie_facebook_likes,actor_1_facebook_likes=actor_1_facebook_likes,imdb_score=imdb_score)
model = svm(imdb_score ~ movie_facebook_likes + actor_1_facebook_likes, data = d)
model
head(d)
head(yourtable$movie_title)

dd<-c(yourtable$movie_title,d)
plot(model,d)

yourtable

#actor2 fblikes

actor_2_facebook_likes=yourtable$actor_2_facebook_likes

movie_facebook_likes=yourtable$movie_facebook_likes

d1= data.frame(movie_facebook_likes=movie_facebook_likes,imdb_score=imdb_score)
model1 = svm(imdb_score ~ movie_facebook_likes, data = d1)
model1
head(d1)
head(yourtable$movie_title)

plot(model1,d1)

yourtable

