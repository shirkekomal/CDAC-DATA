con <- dbConnect(MySQL(), user="Unicorn", password="Unicorn", 
                 dbname="TeamUnicorn", host="localhost",client.flag=CLIENT_MULTI_STATEMENTS)
dbListTables(con)
yourtable <- dbReadTable(con,"data2")




