
#histogram
imdb_score<-yourtable$imdb_score

hist(imdb_score)

#piechart
movie_like <- tail(yourtable$movie_facebook_likes)

movie_title <- tail(yourtable$movie_title)

pie(movie_like,movie_title,col=rainbow(length(movie_like)))

#barchart
imdb_score_head<-head(yourtable$imdb_score)
movie_title_head <- head(yourtable$movie_title)
barplot(imdb_score_head,names.arg=movie_title)


#line graph


