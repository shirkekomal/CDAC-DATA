set.seed(100)
rpois(100,6)
range(rpois(100,6))
range(rpois(100,6))[1]:range(rpois(100,6))[2]
set.seed(100)
cut(rpois(100,6),range(rpois(100,6))[1]:range(rpois(100,6))[2])
cut(rpois(100,6),pretty(rpois(100,6)))
pretty(rpois(100,6))

x <- 1:20       
x
cut(x,c(5,15))
b <- yourtable$duration
b[is.na(b)]<- 0
tail(b)
cut(b,c(50,75100,125,150,175))


