install.packages("xgboost", repos=c("http://dmlc.ml/drat/", getOption("repos")), type="source")
install.packages('xgboost')
library(xgboost)
