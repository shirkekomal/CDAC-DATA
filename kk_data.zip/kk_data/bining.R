set.seed(100)
rpois(100,6)
range(rpois(100,6))
range(rpois(100,6))[1]:range(rpois(100,6))[2]
set.seed(100)
cut(rpois(100,6),range(rpois(100,6))[1]:range(rpois(100,6))[2])
cut(rpois(100,6),pretty(rpois(100,6)))
pretty(rpois(100,6))

x <- 1:20       
x
cut(x,c(0,5,10,15,20))
b <- yourtable$duration
b[is.na(b)]<- 0
b
sort(b)
c <- cut(b,c(0,50,75,100,125,150,175,200,215))
cut(b,c(0,50))
class(as.data.frame(c))
a <- cut(as.numeric(a),c(0,100,150,200,230))
order(a)
plot(a)
