install.packages('e1071')
library(e1071)


#actor2 fblikes
movie_facebook_likes=yourtable$movie_facebook_likes
actor_2_facebook_likes=yourtable$actor_2_facebook_likes
imdb_score <- yourtable$imdb_score
d1= data.frame(movie_facebook_likes=movie_facebook_likes,imdb_score=imdb_score)
model1 = svm(imdb_score ~ movie_facebook_likes + actor_2_facebook_likes, data = d)
model1
head(d1)
head(yourtable$movie_title)

plot(model1,d1)

yourtable

