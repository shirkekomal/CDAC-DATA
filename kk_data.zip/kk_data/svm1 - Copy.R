install.packages('e1071')
library(e1071)

movie_facebook_likes = yourtable$movie_facebook_likes
actor_2_facebook_likes = yourtable$actor_2_facebook_likes
imdb_score1 = factor(yourtable$imdb_score)

d = data.frame(movie_facebook_likes=movie_facebook_likes,imdb_score=imdb_score1)
model = svm(imdb_score1 ~ movie_facebook_likes + genres, data = d)
plot(model, d)
