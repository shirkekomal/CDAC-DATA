class StudentTest1
{
int id;
String first;
String last;

	StudentTest1()
	{
		
	}
	StudentTest1(int id,String first,String last,StudentTest1 s[])
	{
		for(int i=0;i<5;i++)
		{
		if(id==s[i].id)
		{
			System.out.println("String matched");
			break;
		}
		else
		{
			this.id=id;
			this.first=first;
			this.last=last;
		}
		}
	}
}
	class Student1
	{
	public static void main(String args[])
	{
		 StudentTest1[] stud=new StudentTest1[5];
		
		for(int i=0;i<5;i++)
		{
		 stud[i]=new StudentTest1();
		}	
		
		stud[0]=new StudentTest1(1,"komal","Nikam",stud);
		stud[1]=new StudentTest1(2,"kirti","Nikam",stud);
		stud[2]=new StudentTest1(3,"harish","Nikam",stud);
		stud[3]=new StudentTest1(1,"yuvraj","Nikam",stud);
		stud[4]=new StudentTest1(4,"siddharth","Nikam",stud);
		for(int i=0;i<5;i++)
		{
		System.out.println(stud[i].id+"   "+stud[i].first+"   "+stud[i].last);
		}
	}
	
	}
