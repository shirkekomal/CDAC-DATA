
train = read.csv("C:\\Users\\160840320032\\Desktop\\PROJECT\\Training.csv", stringsAsFactors = FALSE)
test = read.csv("C:\\Users\\160840320032\\Desktop\\PROJECT\\Testing.csv", stringsAsFactors = FALSE)

m = train
############
m[m == ""] <- NA

Mode <- function(x) {
  ux <- na.omit(unique(x) )
  tab <- tabulate(match(x, ux)); ux[tab == max(tab) ]
}


Mode(m[,2])

m$director_name = ifelse(is.na(m$director_name) == TRUE, "Others", m$director_name)
m$actor_2_name = ifelse(is.na(m$actor_2_name) == TRUE, "Others", m$actor_2_name)
m$actor_1_name = ifelse(is.na(m$actor_1_name) == TRUE, "Others", m$actor_1_name)
m$actor_3_name = ifelse(is.na(m$actor_3_name) == TRUE, "Others", m$actor_3_name)



for(i in 1:ncol(m)){
  for(j in 1:nrow(m)){
    m[j,i] = ifelse(is.na(m[j,i]) == TRUE & class(m[,i]) == "character", Mode(m[,i]), m[j,i])
  }
}

m = m[,-c(10,17)]
m
train = m

Mean <- function(x) {
  mean(x, na.rm = TRUE)
}

for(i in 1:ncol(m)){
  for(j in 1:nrow(m)){
    m[j,i] = ifelse(is.na(m[j,i]) == TRUE & class(m[,i]) == "integer", Mean(m[,i]), m[j,i])
  }
}

for(i in 1:ncol(m)){
  for(j in 1:nrow(m)){
    m[j,i] = ifelse(is.na(m[j,i]) == TRUE & class(m[,i]) == "numeric", Mean(m[,i]), m[j,i])
  }
}


#################

mt = test
###########
mt[mt == ""] <- NA

Mode <- function(x) {
  ux <- na.omit(unique(x) )
  tab <- tabulate(match(x, ux)); ux[tab == max(tab) ]
}


Mode(mt[,2])



for(i in 1:ncol(mt)){
  for(j in 1:nrow(mt)){
    mt[j,i] = ifelse(is.na(mt[j,i]) == TRUE & class(mt[,i]) == "character", Mode(mt[,i]), mt[j,i])
  }
}

mt = mt[,-c(10,17)]

Mean <- function(x) {
  mean(x, na.rm = TRUE)
}

for(i in 1:ncol(mt)){
  for(j in 1:nrow(mt)){
    mt[j,i] = ifelse(is.na(mt[j,i]) == TRUE & class(mt[,i]) == "integer", Mean(mt[,i]), mt[j,i])
  }
}

for(i in 1:ncol(mt)){
  for(j in 1:nrow(mt)){
    mt[j,i] = ifelse(is.na(mt[j,i]) == TRUE & class(mt[,i]) == "numeric", Mean(mt[,i]), mt[j,i])
  }
}

test = mt
##############
test = as.data.frame(unclass(test))
train = as.data.frame(unclass(train))


train1 = train[,-24]
test1 = test

train_mat <- matrix(as.numeric(data.matrix(train1)),ncol(train1))
test_mat <- matrix(as.numeric(data.matrix(test1)),ncol(test1) )
#CV_mat <- matrix(as.numeric(data.matrix(CV1)),ncol(CV1))

test_mat
train_mat
params = list(verbose=1, 
              eta=0.2, 
              max_depth=6, 
              objective='reg:linear', 
              num_parallel_tree = 1,
              min_child_weight = 1,
              base_score = 7)

##############CV
install.packages('mlr')
library("mlr")
packageurl <- "https://cran.r-project.org/src/contrib/Archive/xgboost/xgboost_0.3-1.tar.gz"
install.packages(packageurl, contriburl=NULL, type="source")


mdcv <- xgb.cv(data=CV_mat, params = params,label = CV$imdb_score, 
               nfold=5, nrounds=200,
               verbose = T)
#####################
xgb_model_test = xgboost(data=train_mat, 
                         label= train$imdb_score, 
                         nrounds = 30,
                         params = params, missing = NaN)


test_preds <- predict(xgb_model_test, test_mat, missing = "NAN")
test_preds_frame <- data.frame(matrix(test_preds, ncol = 1, byrow=TRUE))
colnames(test_preds_frame) <- c("target")

t = test_preds_frame
t$actualRatings = test$imdb_score
t$absdiff = abs(t$actualRatings - t$target)

sum(t$absdiff)


results = test_preds_frame
results$movie_imdb_link = test$movie_imdb_link
results$imdb_score = test_preds_frame$target
results = results[,-1]

write.csv(results, "results.csv", row.names = FALSE)
