#Loading the libraries
install.packages("GGally")
install.packages("tree")
install.packages("rpart")
install.packages("rpart.plot")
install.packages("dplyr")

library(ggplot2)
library(GGally)
library(dplyr)
library(tree)
library(rpart)
library(rpart.plot)
#extracting the numerical variables and store the resulting data in temp
head(yourtable[2])   #<---table data (csv file)
dim(yourtable)[1]#<--- gives row count
columns <- c()
for(i in 1:dim(yourtable)[2])
{
  if(is.numeric(yourtable[,i])|| is.integer(yourtable[,i]))
  {
    columns[i]=T
  }
  else
  {
    columns[i]=F
  }
}
temp <- na.omit(yourtable[,columns])   #<-----omitted allcolumns containing 'na'
temp[2]
head(temp[2])
ggplot(temp, aes(x=imdb_score)) + geom_histogram()
#Simple Linear Model
#check variables correlated to the response variable
correlation <- c()
for(i in 1:dim(temp)[2])
{
  correlation[i] <- cor(temp[,i],temp[,'imdb_score'])
}
correlation
head(correlation[7])

#Scatter Plot to visualize correlation
ggplot(temp, aes(x=num_voted_users, y=imdb_score)) + geom_point(colour="grey60") +
  stat_smooth(method=lm, se=FALSE, colour="black")+ggtitle(paste('R:',correlation[7]))

ggplot(temp, aes(x=budget, y=imdb_score)) + geom_point(colour="grey60") +
  stat_smooth(method=lm, se=FALSE, colour="black")+ggtitle(paste('R:',correlation[1]))

#Linear Model
set.seed(2)
train <- sample(dim(temp)[2],dim(temp)[2]*0.9)
head(train)
temp_train <- temp[train,]
temp_test <- temp[-train,]

#head(cbind(temp_test,temp_train))
head(temp_test)
head(temp_train)


lmfit = lm(imdb_score~num_voted_users+budget,data=temp_train)
lmfit
summary(lmfit)
pred <- predict(lmfit,temp_train)
head(pred)
pred
r <- round(pred,digit=0)
r1 <- round(yourtable$imdb_score,digit=0)
head(r)
movie_title=yourtable$movie_title
movie_title[1:300]
head(cbind(actual= yourtable$imdb_score,prediction=pred),300)
cbind(actual= r1,prediction=r)
cbind(movie_title,actual= yourtable$imdb_score,prediction=pred)
#MSE : mean square error
mean((temp_test$imdb_score-pred)^2)


